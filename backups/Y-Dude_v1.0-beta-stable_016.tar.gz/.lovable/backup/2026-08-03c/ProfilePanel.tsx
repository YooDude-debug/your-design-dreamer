import { useRef, useState, type ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  BadgeCheck,
  MapPin,
  Globe,
  Pencil,
  Settings,
  Menu,
  LayoutGrid,
  Megaphone,
  HelpCircle,
  FileText,
  ShieldCheck,
  Users,
  Lock,
} from "lucide-react";

import { useData } from "@/lib/data-context";
import { useLang } from "@/lib/lang-context";
import { SlangText } from "@/components/SlangTagInput";
import type { LocationVisibility } from "@/lib/types";
import { ProfileEditDialog } from "@/components/ProfileEditDialog";
import { DropdownPortal } from "@/components/DropdownPortal";

import { AdFeedPanel } from "@/components/AdFeed";
import { adFeedLabel } from "@/lib/ad-feed-copy";

const LOC_OPTIONS = [
  {
    value: "public",
    icon: Globe,
    labelKey: "locVisPublic",
    hintKey: "locVisPublicHint",
  },
  {
    value: "connections",
    icon: Users,
    labelKey: "locVisConnections",
    hintKey: "locVisConnectionsHint",
  },
  {
    value: "private",
    icon: Lock,
    labelKey: "locVisPrivate",
    hintKey: "locVisPrivateHint",
  },
] as const satisfies readonly {
  value: LocationVisibility;
  icon: typeof Globe;
  labelKey: "locVisPublic" | "locVisConnections" | "locVisPrivate";
  hintKey: "locVisPublicHint" | "locVisConnectionsHint" | "locVisPrivateHint";
}[];

export function ProfilePanel({ children }: { children?: ReactNode }) {
  const { me, updateMyProfile } = useData();
  const { t, lang } = useLang();
  const navigate = useNavigate();

  const [editOpen, setEditOpen] = useState(false);
  const [editTab, setEditTab] = useState<"profile" | "security">("profile");
  const [menuOpen, setMenuOpen] = useState(false);
  const [adFeedOpen, setAdFeedOpen] = useState(false);
  const [locMenuOpen, setLocMenuOpen] = useState(false);
  const menuRef = useRef<HTMLButtonElement | null>(null);
  const locRef = useRef<HTMLButtonElement | null>(null);

  const setLocationVisibility = async (value: LocationVisibility) => {
    setLocMenuOpen(false);
    if (!me || me.locationVisibility === value) return;
    await updateMyProfile({ locationVisibility: value });
  };

  const openEdit = (tab: "profile" | "security") => {
    setEditTab(tab);
    setEditOpen(true);
    setMenuOpen(false);
  };

  const menuItems: {
    icon: typeof Pencil;
    label: string;
    onClick: () => void;
    accent?: boolean;
  }[] = [
    { icon: Pencil, label: t.editProfile, onClick: () => openEdit("profile"), accent: true },
    {
      icon: LayoutGrid,
      label: t.myPosts,
      onClick: () => {
        setMenuOpen(false);
        void navigate({ to: "/posts" });
      },
    },
    {
      icon: Megaphone,
      label: adFeedLabel(lang),
      onClick: () => {
        setMenuOpen(false);
        setAdFeedOpen(true);
      },
    },
    { icon: Settings, label: t.settings, onClick: () => openEdit("security") },
    { icon: HelpCircle, label: t.help, onClick: () => setMenuOpen(false) },
    {
      icon: FileText,
      label: t.imprint,
      onClick: () => {
        setMenuOpen(false);
        void navigate({ to: "/impressum" });
      },
    },
    {
      icon: ShieldCheck,
      label: t.privacy,
      onClick: () => {
        setMenuOpen(false);
        void navigate({ to: "/datenschutz" });
      },
    },
  ];

  if (!me) {
    return (
      <aside className="rounded-2xl border border-border bg-surface/40 p-5 text-sm text-muted-foreground">
        {t.profileLoading}
      </aside>
    );
  }

  return (
    <aside className="space-y-3">
      <section className="relative rounded-2xl border border-border bg-surface/40">
        {/* Cover */}
        <div className="relative h-20 w-full overflow-hidden rounded-t-2xl bg-gradient-to-r from-brand/20 via-transparent to-brand-cyan/20">
          {me.cover && (
            <img
              src={me.cover}
              alt=""
              loading="eager"
              fetchPriority="high"
              decoding="async"
              className="h-full w-full object-cover opacity-70"
            />
          )}
        </div>

        {/* Hamburger-Menü – liegt über allen Profil- und Composer-Elementen */}
        <button
          ref={menuRef}
          onClick={() => setMenuOpen((v) => !v)}
          aria-label={t.menu}
          aria-expanded={menuOpen}
          title={t.menu}
          className="absolute right-2 top-2 z-[60] grid h-9 w-9 place-items-center rounded-full border border-border bg-background/80 text-muted-foreground backdrop-blur transition-colors hover:border-brand/60 hover:text-brand"
        >
          <Menu className="h-4 w-4" />
        </button>
        <DropdownPortal
          anchorRef={menuRef}
          open={menuOpen}
          onClose={() => setMenuOpen(false)}
          align="right"
          width={224}
        >
          {menuItems.map((a) => (
            <button
              key={a.label}
              onClick={a.onClick}
              className="group flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left text-sm transition-colors hover:bg-brand/10"
            >
              <a.icon
                className={`h-4 w-4 shrink-0 ${a.accent ? "text-brand" : "text-muted-foreground"} group-hover:text-brand`}
              />
              <span className="min-w-0 flex-1 truncate">{a.label}</span>
            </button>
          ))}
        </DropdownPortal>

        {/* Header */}
        <div className="-mt-10 px-5 pb-3 text-center">
          {/* Klick auf Profilbild oder Namen öffnet ausschliesslich die
              öffentliche Profilansicht. Bearbeiten nur über das Menü. */}
          <Link
            to="/profile/$username"
            params={{ username: me.username }}
            aria-label={t.viewProfile}
            className="relative mx-auto block h-24 w-24"
          >
            <div className="absolute -inset-1 rounded-full bg-gradient-brand opacity-60 blur-md" />
            <div className="relative h-24 w-24 overflow-hidden rounded-full border-2 border-brand bg-background shadow-glow">
              {me.avatar ? (
                <img
                  src={me.avatar}
                  alt={me.displayName}
                  loading="eager"
                  fetchPriority="high"
                  decoding="async"
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-3xl font-black text-brand">
                  {me.displayName.slice(0, 1).toUpperCase()}
                </div>
              )}
            </div>
          </Link>

          <Link
            to="/profile/$username"
            params={{ username: me.username }}
            className="mt-1.5 block transition-colors hover:text-brand"
          >
            <h2 className="inline-flex items-center gap-1.5 text-xl font-black tracking-tight">
              {me.displayName}
              {me.verified && <BadgeCheck className="h-4 w-4 text-brand-cyan" />}
            </h2>
            <div className="text-xs text-muted-foreground">@{me.username}</div>
          </Link>

          <div className="mt-1 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
            <button
              ref={locRef}
              onClick={() => setLocMenuOpen((v) => !v)}
              aria-label={t.locationVisibility}
              aria-expanded={locMenuOpen}
              title={t.locationVisibility}
              className="inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 transition-colors hover:bg-brand/10 hover:text-brand"
            >
              <MapPin className="h-3 w-3 text-brand" />
              <span className="max-w-[9rem] truncate">{me.location || t.location}</span>
              {(() => {
                const Icon =
                  LOC_OPTIONS.find((o) => o.value === me.locationVisibility)?.icon ?? Globe;
                return <Icon className="h-3 w-3 text-muted-foreground" />;
              })()}
            </button>
            <DropdownPortal
              anchorRef={locRef}
              open={locMenuOpen}
              onClose={() => setLocMenuOpen(false)}
              align="center"
              width={224}
              className="text-left"
            >
              <div className="px-2 pb-1 text-[10px] uppercase tracking-widest text-muted-foreground">
                {t.locationVisibility}
              </div>
              {LOC_OPTIONS.map((o) => (
                <button
                  key={o.value}
                  onClick={() => void setLocationVisibility(o.value)}
                  className={`flex w-full items-start gap-2 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-brand/10 ${
                    me.locationVisibility === o.value ? "text-brand" : ""
                  }`}
                >
                  <o.icon className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <span className="min-w-0">
                    <span className="block text-xs font-semibold">{t[o.labelKey]}</span>
                    <span className="block text-[10px] text-muted-foreground">{t[o.hintKey]}</span>
                  </span>
                </button>
              ))}
            </DropdownPortal>

            <span className="inline-flex items-center gap-1">
              <Globe className="h-3 w-3 text-brand-cyan" /> {me.language}
            </span>
          </div>

          {me.locationVisibility !== "public" && (
            <p className="mt-1 text-[10px] text-muted-foreground">
              {me.locationVisibility === "connections"
                ? `(${t.locVisFriendsOnly})`
                : t.locVisHiddenNote}
            </p>
          )}

          {me.bio && (
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
              <SlangText text={me.bio} />
            </p>
          )}

          {/* Statistiken liegen ausschliesslich auf der vollstaendigen Profilseite. */}
        </div>

        {/* Composer – gehoert optisch zum Profil, klappt weich aus */}
        {children && (
          <div className="border-t border-border/60 px-4 pb-4 pt-3 text-left sm:px-5">
            {children}
          </div>
        )}
      </section>

      <ProfileEditDialog open={editOpen} initialTab={editTab} onClose={() => setEditOpen(false)} />
      {adFeedOpen && <AdFeedPanel onClose={() => setAdFeedOpen(false)} />}
    </aside>
  );
}
