import type { Lang } from "@/lib/i18n-dict";

/**
 * Texte für das erweiterte Profil, die Profileinstellungen, die Kontolöschung
 * und den DSGVO-Datenexport. Eigenes Wörterbuch, damit das Kernwörterbuch
 * (`i18n-dict.ts`) übersichtlich bleibt.
 */

const de = {
  tabDetails: "Profil",
  tabAccount: "Konto",

  groupPersonal: "Persönliche Informationen",
  groupInterests: "Interessen",
  groupSocial: "Social",
  groupCommunity: "Community",
  groupPrivacy: "Privatsphäre",

  fOrigin: "Herkunft",
  fLanguages: "Sprachen",
  fBirthday: "Geburtstag",
  fPronouns: "Pronomen",
  fInterestTags: "Interessen",
  fHobbies: "Hobbys",
  fMusic: "Lieblingsmusik",
  fGames: "Lieblingsspiele",
  fMovies: "Lieblingsfilme / Serien",
  fSports: "Lieblingssport",
  fWebsite: "Eigene Website",
  fInstagram: "Instagram",
  fTiktok: "TikTok",
  fYoutube: "YouTube",
  fTwitch: "Twitch",
  fDiscord: "Discord",

  visPublic: "Öffentlich",
  visFollowers: "Nur Follower",
  visPrivate: "Privat",
  visHint: "Sichtbarkeit dieses Feldes",

  tagsHint: "Mit Enter oder Komma hinzufügen",
  optional: "optional",
  detailsSaved: "Profil gespeichert",
  detailsSaveFailed: "Speichern fehlgeschlagen",
  showPreview: "Profilvorschau anzeigen",

  about: "Über mich",
  memberSince: "Mitglied seit",
  slangTagRank: "SlangTag-Rang",
  likesReceived: "Erhaltene Likes",
  statComments: "Kommentare",
  statFollowers: "Follower",
  statFollowing: "Folgt",
  verifiedPrepared: "Verifizierung vorbereitet",
  verifiedYes: "Verifiziert",
  verifiedNo: "Noch nicht verifiziert",

  exportTitle: "Meine Daten herunterladen",
  exportDesc:
    "Lade jederzeit eine Kopie deiner persönlichen Daten als ZIP-Archiv herunter (DSGVO, Art. 20).",
  exportHint: "Die Erstellung des Archivs kann je nach Datenmenge einige Minuten dauern.",
  exportButton: "Meine Daten herunterladen",
  exportRunning: "Archiv wird erstellt …",
  exportDone: "Deine Daten wurden erfolgreich exportiert.",
  exportFailed: "Export fehlgeschlagen",
  exportDownload: "Archiv herunterladen",
  exportLinkHint:
    "Der Downloadlink ist 60 Minuten gültig. Danach wird die Datei automatisch gelöscht.",

  deleteTitle: "Account löschen",
  deleteWarning: "Diese Aktion kann nicht rückgängig gemacht werden.",
  deleteDesc:
    "Dein Profil, deine Beiträge, Kommentare, Likes, SlangTags und alle Uploads werden dauerhaft gelöscht.",
  deleteConfirmLabel: "Ich bestätige, dass mein Account dauerhaft gelöscht werden soll.",
  deleteButton: "Account endgültig löschen",
  deleteRunning: "Account wird gelöscht …",
  deleteDone: "Dein Account wurde erfolgreich gelöscht.",
  deleteFailed: "Löschen fehlgeschlagen",
  passwordRequired: "Bitte Passwort eingeben",
  confirmRequired: "Bitte Bestätigung ankreuzen",
  passwordLabel: "Passwort bestätigen",
  tooManyAttempts: "Zu viele Versuche. Bitte später erneut versuchen.",
};

export type ProfileDict = { [K in keyof typeof de]: string };

const en: ProfileDict = {
  tabDetails: "Profile",
  tabAccount: "Account",

  groupPersonal: "Personal information",
  groupInterests: "Interests",
  groupSocial: "Social",
  groupCommunity: "Community",
  groupPrivacy: "Privacy",

  fOrigin: "Origin",
  fLanguages: "Languages",
  fBirthday: "Birthday",
  fPronouns: "Pronouns",
  fInterestTags: "Interests",
  fHobbies: "Hobbies",
  fMusic: "Favourite music",
  fGames: "Favourite games",
  fMovies: "Favourite movies / shows",
  fSports: "Favourite sport",
  fWebsite: "Website",
  fInstagram: "Instagram",
  fTiktok: "TikTok",
  fYoutube: "YouTube",
  fTwitch: "Twitch",
  fDiscord: "Discord",

  visPublic: "Public",
  visFollowers: "Followers only",
  visPrivate: "Private",
  visHint: "Visibility of this field",

  tagsHint: "Add with Enter or comma",
  optional: "optional",
  detailsSaved: "Profile saved",
  detailsSaveFailed: "Saving failed",
  showPreview: "Show profile preview",

  about: "About me",
  memberSince: "Member since",
  slangTagRank: "SlangTag rank",
  likesReceived: "Likes received",
  statComments: "Comments",
  statFollowers: "Followers",
  statFollowing: "Following",
  verifiedPrepared: "Verification prepared",
  verifiedYes: "Verified",
  verifiedNo: "Not verified yet",

  exportTitle: "Download my data",
  exportDesc: "Download a copy of your personal data as a ZIP archive at any time (GDPR, Art. 20).",
  exportHint: "Creating the archive can take a few minutes depending on the amount of data.",
  exportButton: "Download my data",
  exportRunning: "Creating archive …",
  exportDone: "Your data was exported successfully.",
  exportFailed: "Export failed",
  exportDownload: "Download archive",
  exportLinkHint:
    "The download link is valid for 60 minutes. Afterwards the file is deleted automatically.",

  deleteTitle: "Delete account",
  deleteWarning: "This action cannot be undone.",
  deleteDesc:
    "Your profile, posts, comments, likes, SlangTags and all uploads will be permanently deleted.",
  deleteConfirmLabel: "I confirm that my account should be permanently deleted.",
  deleteButton: "Delete account permanently",
  deleteRunning: "Deleting account …",
  deleteDone: "Your account was deleted successfully.",
  deleteFailed: "Deletion failed",
  passwordRequired: "Please enter your password",
  confirmRequired: "Please tick the confirmation",
  passwordLabel: "Confirm password",
  tooManyAttempts: "Too many attempts. Please try again later.",
};

const el: ProfileDict = {
  tabDetails: "Προφίλ",
  tabAccount: "Λογαριασμός",

  groupPersonal: "Προσωπικές πληροφορίες",
  groupInterests: "Ενδιαφέροντα",
  groupSocial: "Social",
  groupCommunity: "Κοινότητα",
  groupPrivacy: "Ιδιωτικότητα",

  fOrigin: "Καταγωγή",
  fLanguages: "Γλώσσες",
  fBirthday: "Γενέθλια",
  fPronouns: "Αντωνυμίες",
  fInterestTags: "Ενδιαφέροντα",
  fHobbies: "Χόμπι",
  fMusic: "Αγαπημένη μουσική",
  fGames: "Αγαπημένα παιχνίδια",
  fMovies: "Αγαπημένες ταινίες / σειρές",
  fSports: "Αγαπημένο άθλημα",
  fWebsite: "Ιστοσελίδα",
  fInstagram: "Instagram",
  fTiktok: "TikTok",
  fYoutube: "YouTube",
  fTwitch: "Twitch",
  fDiscord: "Discord",

  visPublic: "Δημόσιο",
  visFollowers: "Μόνο ακόλουθοι",
  visPrivate: "Ιδιωτικό",
  visHint: "Ορατότητα αυτού του πεδίου",

  tagsHint: "Προσθήκη με Enter ή κόμμα",
  optional: "προαιρετικό",
  detailsSaved: "Το προφίλ αποθηκεύτηκε",
  detailsSaveFailed: "Η αποθήκευση απέτυχε",
  showPreview: "Προεπισκόπηση προφίλ",

  about: "Σχετικά με εμένα",
  memberSince: "Μέλος από",
  slangTagRank: "Κατάταξη SlangTag",
  likesReceived: "Likes που έλαβα",
  statComments: "Σχόλια",
  statFollowers: "Ακόλουθοι",
  statFollowing: "Ακολουθεί",
  verifiedPrepared: "Η επαλήθευση προετοιμάστηκε",
  verifiedYes: "Επαληθευμένο",
  verifiedNo: "Δεν έχει επαληθευτεί ακόμη",

  exportTitle: "Λήψη των δεδομένων μου",
  exportDesc:
    "Κατέβασε ανά πάσα στιγμή αντίγραφο των προσωπικών δεδομένων σου ως αρχείο ZIP (GDPR, άρθρο 20).",
  exportHint: "Η δημιουργία του αρχείου μπορεί να διαρκέσει λίγα λεπτά.",
  exportButton: "Λήψη των δεδομένων μου",
  exportRunning: "Δημιουργία αρχείου …",
  exportDone: "Τα δεδομένα σου εξήχθησαν με επιτυχία.",
  exportFailed: "Η εξαγωγή απέτυχε",
  exportDownload: "Λήψη αρχείου",
  exportLinkHint: "Ο σύνδεσμος ισχύει για 60 λεπτά. Στη συνέχεια το αρχείο διαγράφεται αυτόματα.",

  deleteTitle: "Διαγραφή λογαριασμού",
  deleteWarning: "Αυτή η ενέργεια δεν μπορεί να αναιρεθεί.",
  deleteDesc:
    "Το προφίλ, οι δημοσιεύσεις, τα σχόλια, τα likes, τα SlangTags και όλα τα αρχεία σου θα διαγραφούν οριστικά.",
  deleteConfirmLabel: "Επιβεβαιώνω ότι ο λογαριασμός μου πρέπει να διαγραφεί οριστικά.",
  deleteButton: "Οριστική διαγραφή λογαριασμού",
  deleteRunning: "Διαγραφή λογαριασμού …",
  deleteDone: "Ο λογαριασμός σου διαγράφηκε με επιτυχία.",
  deleteFailed: "Η διαγραφή απέτυχε",
  passwordRequired: "Εισάγετε τον κωδικό σας",
  confirmRequired: "Επιβεβαιώστε την επιλογή",
  passwordLabel: "Επιβεβαίωση κωδικού",
  tooManyAttempts: "Πάρα πολλές προσπάθειες. Δοκιμάστε ξανά αργότερα.",
};

export const profileTexts: Record<Lang, ProfileDict> = { de, en, el };

/** Feldbeschriftung je Sprache. */
export const FIELD_LABEL_KEY = {
  origin: "fOrigin",
  languages: "fLanguages",
  birthday: "fBirthday",
  pronouns: "fPronouns",
  interestTags: "fInterestTags",
  hobbies: "fHobbies",
  music: "fMusic",
  games: "fGames",
  movies: "fMovies",
  sports: "fSports",
  website: "fWebsite",
  instagram: "fInstagram",
  tiktok: "fTiktok",
  youtube: "fYoutube",
  twitch: "fTwitch",
  discord: "fDiscord",
} as const;
